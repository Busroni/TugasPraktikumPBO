package tugaspertemuan5;

public class TugasPertemuan5 {
    public static void main(String[] args) {
        View view=new View();
    }
}
