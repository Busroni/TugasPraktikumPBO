package tugaspertemuan5;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import ruang.Balok;

public class View extends JFrame implements ActionListener{
   private JButton btnHitung;
   private JButton btnReset;

   double panjang;
   double lebar;
   double tinggi;
   JTextField fpanjang;
   JTextField flebar;
   JTextField ftinggi;
   JLabel lvluas;
   JLabel lvkeliling;
   JLabel lvvolume;
   JLabel lvlp;
   
   
    public View(){
	super("Tugas Pertemuan 5");

	JLabel lbl = new JLabel("Kalkulator");
	JLabel bal = new JLabel("Balok");
	btnHitung = new JButton("Hitung");
	btnReset = new JButton("Reset");
        
        JLabel lpanjang = new JLabel("Panjang");
        fpanjang = new JTextField(10);
        
        JLabel llebar = new JLabel("Lebar");
        flebar = new JTextField(10);
        
        JLabel ltinggi = new JLabel("Tinggi");
        ftinggi = new JTextField(10);

       	JLabel lluas =new JLabel("Luas : ");
	lvluas =new JLabel("");

        JLabel lkeliling =new JLabel("Keliling : ");
	lvkeliling =new JLabel("");

        JLabel lvolume =new JLabel("Volume : ");
	lvvolume =new JLabel("");

	JLabel llp =new JLabel("Luas Permukaan : ");
	lvlp =new JLabel("");

	btnHitung.addActionListener(this);
	btnReset.addActionListener(this);
	setLayout(new GridLayout(10,2));
	add(lbl);
	add(bal);
	add(lpanjang);
	add(fpanjang);
	add(llebar);
	add(flebar);
	add(ltinggi);
	add(ftinggi);
	add(lluas);
	add(lvluas);
	add(lkeliling);
	add(lvkeliling);
	add(lvolume);
	add(lvvolume);
	add(llp);
	add(lvlp);
        add(btnHitung);
	add(btnReset);


	pack();
	setVisible(true);
	setDefaultCloseOperation(EXIT_ON_CLOSE);
;
   }

   public void actionPerformed(ActionEvent e){
	if(e.getSource()==btnHitung){
            if (fpanjang.getText().isEmpty()||flebar.getText().isEmpty()|| ftinggi.getText().isEmpty()){
               JOptionPane.showMessageDialog(null, "Form masih ada yang kosong");
            }
            else
            {    
                try{              
                    panjang = Double.parseDouble(fpanjang.getText());
                    lebar = Double.parseDouble(flebar.getText());
                    tinggi = Double.parseDouble(ftinggi.getText());   
                    Balok balok=new Balok(tinggi,panjang,lebar);
                    lvluas.setText(Double.toString(balok.hitungLuas()));
                    lvkeliling.setText(Double.toString(balok.hitungKeliling()));
                    lvvolume.setText(Double.toString(balok.menghitungVolume()));
                    lvlp.setText(Double.toString(balok.menghitungLuasPermukaan()));
                }catch(Exception err){
                    JOptionPane.showMessageDialog(this, "Isian tidak boleh berupa String");
                }              
            }
	}
	if(e.getSource()==btnReset){
               fpanjang.setText("");
               flebar.setText("");
               ftinggi.setText("");
               lvluas.setText("");
               lvkeliling.setText("");
               lvlp.setText("");
               lvvolume.setText("");
	}
   }
    
   public void actionButton(ActionEvent e){
       
       if (fpanjang.getText().isEmpty()||flebar.getText().isEmpty()|| ftinggi.getText().isEmpty()){
            JOptionPane.showMessageDialog(null, "Form masih ada yang kosong");
        }
        else
        {
            
       panjang = Double.parseDouble(fpanjang.getText());
       lebar = Double.parseDouble(flebar.getText());
       tinggi = Double.parseDouble(ftinggi.getText());
       
            
        }
   }

}

