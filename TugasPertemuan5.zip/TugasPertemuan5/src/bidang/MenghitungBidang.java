package bidang;

public interface MenghitungBidang {
    double hitungLuas();
    double hitungKeliling();
}
