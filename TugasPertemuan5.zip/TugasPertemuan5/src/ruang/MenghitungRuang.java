package ruang;

public interface MenghitungRuang {
    double menghitungVolume();
    double menghitungLuasPermukaan();
}
